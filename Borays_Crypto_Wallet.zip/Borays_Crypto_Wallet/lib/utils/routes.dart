class MyRoutes {
  static String loginRoute = '/login';
}
